function getIndex(s)
{
    var categories=context.categories 
    for(var i=0;i<categories.length;i++)
    {
        if(categories[i]===s)
                return i
    }
    return -1;
}
